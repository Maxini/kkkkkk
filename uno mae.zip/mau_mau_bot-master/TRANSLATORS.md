# Translators

The following awesome people contributed to this project by translating it:

| Locale | Translators                                                                                                                                                |
| ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ca_CA  | [retiolus](https://github.com/retiolus)                                                                                                                    |
| de_DE  | [Jannes Höke](https://github.com/jh0ker)                                                                                                                   |
| es_ES  | [José.A Rojo](https://github.com/J4RV), [Ricardo Valverde Hernández](https://telegram.me/rivh1), Victor, Yuga                                              |
| id_ID  | [Erwin Guo](https://www.facebook.com/erwinfransiscus)                                                                                                      |
| it_IT  | Carola Mariano, ɳick                                                                                                                                       |
| ml_IN  | [Adhith T](https://github.com/adhitht123)                                                                                                                  |
| pt_BR  | [Iuri Guilherme](https://github.com/iuriguilherme), [João Rodrigo Couto de Oliveira](http://twitter.com/JoaoRodrigoJR)                                     |
| uz_UZ  | [Shohrux V](https://www.instagram.com/shohrux.v/)                                                                                                          |
| vi_VN  | [Lê Minh Sơn](https://github.com/leminhson06)                                                                                                              |
| zh_CN  | [imlonghao](https://github.com/imlonghao), [XhyEax](https://github.com/XhyEax)                                                                             |
| zh_HK  | [Jed Cheng](https://www.facebook.com/profile.php?id=100002258388821)                                                                                       |
| zh_TW  | [Eugene Lam](https://www.facebook.com/eugenelam1118), [jimchen5209](https://www.youtube.com/user/jimchen5209), [pan93412](https://www.github.com/pan93412) |

Please add yourself here alphabetically when you submit your first translation.
